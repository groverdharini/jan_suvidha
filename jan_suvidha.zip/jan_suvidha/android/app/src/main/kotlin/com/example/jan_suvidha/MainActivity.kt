package com.example.jan_suvidha

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
