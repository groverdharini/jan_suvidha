import 'package:flutter/material.dart';
import 'list.dart';

class HomeCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
        children: <Widget>[
    Container(
    decoration: new BoxDecoration(
    border: Border.all(color: Colors.black, width: 4),
    color: Colors.purple,
    gradient: new LinearGradient(
    colors: [Colors.lightGreenAccent, Colors.white],
    ),
    boxShadow: [
    new BoxShadow(
    color: Color(0xff514a9d),
    offset: new Offset(20.0, 30.0),
    blurRadius: 40.0,
    )
    ],
    ),
    height: 250,
    width: 350,
    child: Card(
    elevation: 7.0,
    child: Container(
    padding: EdgeInsets.only(
    left: 12.0, top: 180.0, right: 2.0, bottom: 2.0),
    decoration: BoxDecoration(
    image: DecorationImage(
    image: AssetImage("assets/detect12.png"),
    fit: BoxFit.cover,
    alignment: Alignment.topCenter,
    ),
    ),
      child: Card1(),
    ),

    ),

    ),

    SizedBox(height: 10),
    Container(
    decoration: new BoxDecoration(
    border: Border.all(color: Colors.black, width: 4),
    color: Colors.purple,
    gradient: new LinearGradient(
    colors: [Colors.lightGreenAccent, Colors.white],
    ),
    boxShadow: [
    new BoxShadow(
    color: Color(0xff514a9d),
    offset: new Offset(20.0, 30.0),
    blurRadius: 40.0,
    )
    ],
    ),
    height:250,
    width: 350,
    child: Card(
    elevation: 7.0,
    child: Container(
    padding: EdgeInsets.only(
    left: 12.0, top: 180.0, right: 2.0, bottom: 5.0),
    decoration: BoxDecoration(
    image: DecorationImage(
    image: AssetImage("assets/report12.png"),
    fit: BoxFit.cover,
    alignment: Alignment.topCenter,
    ),
    ),
      child: Card2(),
    ),
    ),

    ),

    SizedBox(height: 10),
    Container(
    decoration: new BoxDecoration(
    border: Border.all(color: Colors.black, width: 5),
    color: Colors.purple,
    gradient: new LinearGradient(
    colors: [Colors.lightGreenAccent, Colors.white],
    ),
    boxShadow: [
    new BoxShadow(
    color: Color(0xff514a9d),
    offset: new Offset(20.0, 30.0),
    blurRadius: 40.0,
    )
    ],
    ),
    height: 250,
    width: 350,

    child: Card(
    elevation: 7.0,
    child: Container(
    padding: EdgeInsets.only(
    left: 12.0, top: 180.0, right: 2.0, bottom: 5.0),
    decoration: BoxDecoration(
    image: DecorationImage(
    image: AssetImage("assets/rewarded.png"),
    fit: BoxFit.cover,
    alignment: Alignment.topCenter,
    ),
    ),
     child: Card3(),
    ),
    ),
    ),

        ],
    );
  }
}